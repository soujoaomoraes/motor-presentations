---
name: apresentacao-html-interativa
description: Cria e edita apresentações interativas em HTML (arquivo único, offline): pitch, runbook com caminhos, canvas, dinâmicas com objetos móveis e diagramas. Use para qualquer apresentação/deck/slides ou HTML com "motor-apresentacao".
---

# Apresentação HTML interativa

Toda apresentação é um único arquivo `.html` com quatro partes: **guia + tema**, **estilo e efeitos próprios**, **conteúdo** (os slides) e **motor** (compactado, sempre igual). Você só escreve as três primeiras. O motor é copiado, nunca digitado nem lido.

Use esta skill no lugar de PowerPoint e do tipo Slides, a menos que a pessoa peça explicitamente um arquivo .pptx.

## Arquivos do motor

Ficam no repositório público **github.com/soujoaomoraes/motor-presentations**:

| Arquivo | Uso |
|---|---|
| `base.html` | Esqueleto: guia de edição, tema (modo escuro e claro), blocos `estilo` e `efeitos` vazios, marcador `<!-- SLIDES AQUI -->`. ~2 mil tokens, pode ler. |
| `motor.min.html` | Motor compactado (~80 KB). Vai no fim do arquivo final. **Nunca leia nem reescreva.** |
| `motor.legivel.html` | Mesmo motor, legível. Só para manutenção do motor, quando pedirem. |
| `modelo.html` | Apresentação de exemplo com todos os tipos de slide. Consulte trechos com `grep`, não leia inteiro. |
| `montar.py` | Script que junta as partes com a base e o motor (passo 4). |
| `manutencao/` | Fontes do motor e o script que gera a versão compactada. |

Baixe direto para a pasta de trabalho, sem passar pelo contexto (prefere a etiqueta de versão e cai para `main` se ela não existir):

```bash
U=https://raw.githubusercontent.com/soujoaomoraes/motor-presentations; V=v3
curl -sfLO $U/$V/base.html || V=main
for f in base.html motor.min.html montar.py; do curl -sfLO $U/$V/$f; done
```

Plano B, se o GitHub não responder: artifact **Motor de Apresentações HTML** (https://claude.ai/artifact/YFXjLNf3CBkGPVdHUVJ8vZ) com `Artifact` `action: "read"`, `paths: ["base.html", "motor.min.html"]` e `out_dir` na pasta de trabalho (também grava em disco sem ler). Ele é privado de quem publicou.

Plano C, sem internet ou em outra IA: use qualquer apresentação já feita com este modelo, recortando por script, sem ler:
- `motor.min.html` = da linha que contém `MOTOR v` até o fim;
- `base.html` = do início até a linha `INÍCIO DO CONTEÚDO`, depois `<!-- SLIDES AQUI -->`, depois as linhas `FIM DO CONTEÚDO` e `</main>`. Esvazie os blocos `estilo` e `efeitos`, que pertencem à apresentação antiga.

Se nada disso estiver disponível, peça à pessoa o arquivo `modelo.html`.

## Criar uma apresentação

### 1. Entender o pedido

Antes de construir, tenha claro: objetivo, público, onde e como será apresentado (tela, chamada, impresso, consulta), duração, conteúdo-fonte, marca ou referências. Pergunte só o que faltar e não der para deduzir, de preferência numa rodada só.

Escolha os tipos de slide pelo objetivo (podem se misturar no mesmo arquivo):

- **Apresentar** (pitch, relatório, aula): texto e componentes.
- **Guiar** (runbook, triagem, procedimento): slides `data-ramo` com botões `.caminho`. O mapa (tecla M) é gerado sozinho.
- **Preencher** (canvas, mapa de responsabilidades, formulário): `.campo[data-dica]`.
- **Mover** (Moving Motivators, priorização, votação): objetos `.livre` sobre um fundo `.area` ou `.zonas`.
- **Construir junto** (cadeia de valor, retro, mapa de empatia, fluxograma): objetos `.livre` soltos, conexões `.liga`, `class="slide topo"`.

### 2. Direção criativa (pense, não copie)

O motor não tem opinião de estilo e não anima nada sozinho. Cada apresentação ganha uma direção própria, decidida a partir do assunto:

- **Com marca definida**: aplique as cores e a fonte dela no bloco `:root` do TEMA. Materiais da Syos seguem a skill `marca-syos`, com capa e último slide em fundo branco.
- **Com referências**: identifique o que faz a referência funcionar (ritmo, contraste, hierarquia, densidade, tipo de movimento) e traga esses princípios, sem copiar o visual.
- **Sem marca nem referência**: proponha uma direção como um diretor de arte faria, olhando para o mundo do assunto (materiais, vocabulário, instrumentos, público). Defina paleta, par tipográfico, linguagem de layout e linguagem de movimento, e diga em uma ou duas frases o porquê.
- **Movimento com função**: anime só o que ajuda o conteúdo. Revelar por clique para segurar um argumento, contador para dar peso a um número, transição que acompanha a direção da navegação. Num runbook consultado sob pressão, o certo é quase nenhum movimento.
- **Evite os vícios de IA**: tudo centralizado, tudo surgindo de baixo do mesmo jeito, gradiente roxo e azul, ícone ou emoji em todo título, três cartões iguais em todo slide, creme com serifa e terracota por padrão, numeração 01/02/03 sem sequência real.
- **Apresentações longas ou de alto risco**: monte 1 ou 2 slides de teste com a direção escolhida e mostre antes de fazer o resto. Gosto é subjetivo; o teste evita refazer tudo.

### 3. Escrever as partes (numa pasta de trabalho)

- `slides.html`: as `<section class="slide">`, uma por slide. Cada slide mede **1920x1080**.
- `estilo.css` (opcional): visual e animações desta apresentação, usando os encaixes do motor.
- `efeitos.js` (opcional): efeitos especiais (ex.: número que conta).
- `tema.css` (opcional): bloco TEMA completo, quando a marca ou a direção mudar as cores e a fonte.
- `titulo.txt`: título da apresentação.

O guia no topo de `base.html` lista todas as classes. Regras que mais causam erro:

- `id` único, minúsculo, com hífen. Ele é o link do slide (`arquivo.html#id`) e o destino dos botões.
- Botão de caminho: `<a class="caminho" href="#destino"><strong>Texto</strong><small>detalhe</small></a>`. `data-fim` nos ramos que encerram um fluxo.
- Objeto livre: filho **direto** do `<section>`, com `class="livre <tipo>"`, `data-id` único no slide e `style="left:..px; top:..px; width:..px"` em coordenadas do slide (1920x1080). Use `slide topo` para que o layout não desloque os objetos.
- Conexão: `<i class="liga" data-tipo="seta" data-de="o1" data-para="o2"></i>` no mesmo slide dos objetos.
- Elemento específico de uma dinâmica (ex.: carta) é criado no próprio slide. As pessoas duplicam com Ctrl+D. Não invente elementos padrão novos sem pedido.
- Notas do apresentador: `<aside class="notas">` no fim do slide.
- Encaixes de animação (para o `estilo.css`): `.slide.ativo`, `.slide.saindo`, `#palco[data-direcao="frente|tras"]`, `[data-passo]` + `.visto` (revela a cada clique; mesmo número aparecem juntos), eventos `slide:entrou`, `slide:saiu` e `slide:passo` no `document`. O padrão do motor para passo não revelado é `visibility:hidden` com especificidade zero, então qualquer regra sua prevalece.
- Funciona offline: imagens em `data:` URI, gráficos desenhados em SVG no próprio slide, sem bibliotecas externas. Fonte do Google Fonts só carrega com internet; para garantir offline, use fontes do sistema ou embuta a fonte (aumenta o arquivo).

### 4. Montar

```bash
python3 montar.py . saida.html
```

`montar.py` vem do repositório. Se precisar recriá-lo:

```python
import pathlib, re, sys
m, saida = pathlib.Path(sys.argv[1]), sys.argv[2]
base, motor = (m/'base.html').read_text(), (m/'motor.min.html').read_text()
ler = lambda n: pathlib.Path(n).read_text() if pathlib.Path(n).exists() else None
base = base.replace('<!-- SLIDES AQUI -->', ler('slides.html'))
for arq, bloco in [('estilo.css', 'style id="estilo"'), ('efeitos.js', 'script id="efeitos"'), ('tema.css', 'style id="tema"')]:
    t = ler(arq)
    if t is not None:
        tag = bloco.split()[0]
        base = re.sub(r'(?m)^(<%s>)[\s\S]*?(</%s>)' % (re.escape(bloco), tag), lambda x: x.group(1) + '\n' + t.strip() + '\n' + x.group(2), base, count=1)
if ler('titulo.txt'): base = base.replace('TÍTULO DA APRESENTAÇÃO', ler('titulo.txt').strip())
pathlib.Path(saida).write_text(base + motor)
```

Se `tema.css` for usado, ele substitui o bloco TEMA inteiro: mantenha as variáveis `--destaque --sobre-destaque --ok --alerta --erro --postit-1..4 --fonte --raio` e as cores de superfície dos dois modos (`[data-modo="escuro"]` e `[data-modo="claro"]`).

### 5. Verificar (uma passada)

Abra o arquivo com Playwright e:

- chame `apresentacao.analisar().problemas` (links quebrados, passos soltos, becos sem saída) e confira se há erros no console;
- tire uma captura de alguns slides representativos, ou de todos se forem poucos, com `apresentacao.ir('id')`, e corrija texto estourando, sobreposição e contraste.

Uma rodada de correção, sem repetir em loop.

### 6. Entregar

Grave o arquivo final em outputs (ou na pasta conectada da pessoa). Lembre em uma linha: abrir no Chrome ou no Edge; Ctrl+S salva no próprio arquivo (na primeira vez o navegador pergunta onde, e é só escolher o próprio arquivo).

## Editar uma apresentação existente

O objetivo é nunca ler nem reescrever o motor.

- Com ferramentas de arquivo: `grep -n "FIM DO CONTEÚDO\|MOTOR v" arquivo.html` para achar os limites. Leia só até `FIM DO CONTEÚDO`, ou só o slide (`grep -n 'id="nome-do-slide"'`), e altere com substituição pontual (Edit / str_replace) só a `<section>`, o TEMA, o ESTILO ou o EFEITOS. Nunca regrave o arquivo inteiro.
- Sem ferramentas de arquivo (alguém colou o HTML num chat): devolva só o trecho alterado (a `<section>` inteira ou o bloco) e diga exatamente onde colar. Não reproduza o arquivo todo.
- Pessoas também editam direto no navegador: texto, objetos, cores, notas, botões de caminho, slides novos. Pergunte se a versão mais recente do arquivo é a que você tem antes de editar.

## Atualizar o motor de um arquivo antigo

Troque tudo a partir da linha com `MOTOR v` pelo conteúdo de `motor.min.html` atual (por script, sem ler) e atualize a meta `motor-apresentacao`. O conteúdo não muda.

## Manutenção do motor (só quando pedirem)

No repositório, edite `manutencao/motor.css` e `manutencao/motor.js`. Gere os arquivos com `npm install terser csso && node build.js .` dentro de `manutencao/` (saem em `manutencao/dist/`), mantendo os ids `motor-css` e `motor-js` e a linha marcadora `MOTOR vN`. Teste com o `modelo.html` (navegação, passos, apresentador, mapa, objetos, conexões, salvar). Suba os arquivos novos na raiz, crie uma etiqueta nova (`v4`, `v5`...) e atualize `V=` neste SKILL.md. Republique também no artifact do plano B.
